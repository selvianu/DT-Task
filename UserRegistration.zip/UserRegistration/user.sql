CREATE TABLE userdetails (username VARCHAR(100),password1 VARCHAR(20),password2 VARCHAR(20),email VARCHAR(50),dob DATE);
INSERT INTO userdetails VALUES("selvi","nithin","nithin","selvi@gmail.com","2000-08-10");
SELECT * FROM userdetails WHERE username="niit";