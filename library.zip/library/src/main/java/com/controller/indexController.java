package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Servlet implementation class indexController
 */
@Controller

public class indexController {
	String message = "hello MVC";

	@RequestMapping(value = { "/", "/home" })
	public String showMessage() {
		System.out.println("in controller");
		return "index";
	}

	@RequestMapping("/signin")
	public String Login() {
		return "signin";
	}

	@RequestMapping("/register")
	public String register() {
		return "register";
	}

	

	@RequestMapping(value = "/indexController", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password) {

		if (username.equals("niit") && (password.equals("ambattur")))

		{
			message = "Welcome " + username + ".";

			return "success";
		} else {
			message = "Wrong username or password.";
			return "signin";
		}
	}

}
